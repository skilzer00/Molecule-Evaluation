import java.awt.EventQueue;
import java.awt.FileDialog;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import java.awt.TextField;
import java.awt.Button;
import java.awt.TextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import java.io.PrintWriter;
import java.io.Writer;
import javax.swing.JLabel;
import java.awt.Color;

public class PrimeAnalyze {

	private JFrame frmPrimeanalyzer;
	private JTextField txtInputNumber;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PrimeAnalyze window = new PrimeAnalyze();
					window.frmPrimeanalyzer.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public PrimeAnalyze() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmPrimeanalyzer = new JFrame();
		frmPrimeanalyzer.setBackground(Color.BLACK);
		frmPrimeanalyzer.setForeground(Color.BLACK);
		frmPrimeanalyzer.setTitle("PrimeAnalyzer");
		frmPrimeanalyzer.setBounds(100, 100, 449, 342);
		frmPrimeanalyzer.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmPrimeanalyzer.getContentPane().setLayout(null);
		
		TextArea textArea = new TextArea();
		textArea.setBounds(10, 37, 223, 176);
		frmPrimeanalyzer.getContentPane().add(textArea);
		
		txtInputNumber = new JTextField();
		txtInputNumber.setEditable(false);
		txtInputNumber.setText("Input Number :");
		txtInputNumber.setBounds(10, 11, 86, 20);
		frmPrimeanalyzer.getContentPane().add(txtInputNumber);
		txtInputNumber.setColumns(10);
		
		TextField input = new TextField();
		input.setBounds(102, 11, 39, 20);
		frmPrimeanalyzer.getContentPane().add(input);
		
		Button button = new Button("Check");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Store Value input from user into string
				String str = input.getText();
				//Convert string to int using parse
				int num = Integer.parseInt(str);
				//using flags to make sure number is prime
				int flag = 0;
				
				for(int i = 2; i < num; i++) {
					if(num%i==0) {
						flag = 1;
					}
				}
				
				if (flag==0) {
					textArea.setText(textArea.getText() + num + " -PRIME\n");
				}
				else {
					textArea.setText(textArea.getText()+num+ " -COMPOSITE\n");
				}
				
			}
		});
		button.setBounds(161, 11, 70, 22);
		frmPrimeanalyzer.getContentPane().add(button);
		
		Button reset = new Button("Cancel");
		reset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textArea.setText("");
				input.setText("");
			}
		});
		reset.setBounds(10, 219, 77, 22);
		frmPrimeanalyzer.getContentPane().add(reset);
		
		Button save = new Button("Save File in C:/Temp");
		save.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try { 

			        String content = textArea.getText(); //saving input queries

			        File file = new File("C:/temp/inputFile.txt"); //making sure file does not exist

			        // if file does not exists, then we create it
			        if (!file.exists()) {   // checks whether the file is Exist or not
			            file.createNewFile(); 
			        }

			        FileWriter fw = new FileWriter(file.getAbsoluteFile(), true); // creating fileWriter object with the file
			        BufferedWriter bw = new BufferedWriter(fw); // creating bufferWriter which is used to write the content into the file
			        bw.write(content); // write method is used to write the given content into the file
			        bw.close(); // Closes to preven any IO exceptions. 

			        System.out.println("Queries have been Saved");

			    } catch (IOException e1) { // if any exception occurs it will catch
			        e1.printStackTrace();
			    }
				}
			}
		);
		save.setBounds(161, 221, 131, 20);
		frmPrimeanalyzer.getContentPane().add(save);
		
		JButton btnNewButton = new JButton("Load File From C:/Temp");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Load Data From Text File
				BufferedReader br = null;
				try {
					br = new BufferedReader(new FileReader("C:/temp/Numbers.txt"));
					int val = Integer.parseInt(br.readLine()); // read the first line from file
					for(int i=0; i<val;i++) {
						String s = br.readLine(); // read data from file
						int num = Integer.parseInt(s);
						//using flags to make sure number is prime
						int flag = 0;
						
						for(int j = 2; j < num; j++) {
							if(num%j==0) {
								flag = 1;
							}
						}
						
						if (flag==0) {
							textArea.setText(textArea.getText() + num + " -PRIME\n");
						}
						else {
							textArea.setText(textArea.getText()+num+ " -COMPOSITE\n");
						}
					}
				}
					catch(Exception e1) {
						System.out.println(e1);
					}
					finally {
						try {
							br.close();
						}catch(Exception e1) {
							System.out.println(e1);
						}
					}
				}
		});
		btnNewButton.setBounds(245, 109, 163, 23);
		frmPrimeanalyzer.getContentPane().add(btnNewButton);
	}
}
